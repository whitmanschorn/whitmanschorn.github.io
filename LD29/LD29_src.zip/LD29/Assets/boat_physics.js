#pragma strict

var damageConstant : float;
var carHealth : float;

//var sColors=[“green”,“pink”];

var sColors=["green", "pink"];

var mColors =["purple","yellow","teal"];

var lColors = ["orange", "red", "black"]; 

var hullTypes = ["semicircle"];


var sceneManager : GameObject;

var massCO : float;
var hull : GameObject;
var prow : GameObject;
var width : float;
var length: float;
var hullType : String;
var target_go : GameObject;
var modifiedTarget : Vector3;
var speed : float;
var speedCO : float;
var maxTurnVelocity : float;
var crashSFX : AudioClip;
var blip1 : AudioClip;
var blip2 : AudioClip;
var blip3 : AudioClip;
var audioCo : AudioSource;
var wrecked : boolean;
var blips : Array;
var size : int;
var particlePrefab : GameObject;


function Start () {
	sceneManager = GameObject.FindGameObjectWithTag("GameController");

	wrecked = false;
	massCO = 100;
	speedCO = 30.0 * massCO;
	maxTurnVelocity = 5.0f;
	//set rigidbody mass to be the transform.x * transform.y * 5
	var tonnage =  gameObject.transform.localScale.x * gameObject.transform.localScale.y * 5;
	var rg2 = gameObject.GetComponent(Rigidbody2D);
	rg2.mass = tonnage;
	//Debug.Log("SET MASS: " + tonnage);
	
	crashSFX = Resources.Load("sounds/sink_1", AudioClip);
	blip1 = Resources.Load("sounds/blip_1", AudioClip);
	blip2 = Resources.Load("sounds/blip_2", AudioClip);
	blip3 = Resources.Load("sounds/blip_3", AudioClip);
	blips = [blip1, blip2, blip3];
	
	audioCo = gameObject.GetComponent("AudioSource");

	
	generateShip();

}

function Update () {
		if(!wrecked){
		if( target_go ){
		Debug.DrawLine( transform.position , target_go.transform.position );
		Debug.DrawRay(transform.position, transform.right * 10, Color.yellow);
			}
			
		
		var hit : RaycastHit2D = Physics2D.Linecast(transform.position + transform.right * transform.localScale.x, target_go.transform.position);
		
		var targetRelativeV2 : Vector2 = target_go.transform.position - transform.position;
		var targetBearing = getBearingFromVector2( targetRelativeV2 );
		var adj = targetBearing - transform.eulerAngles.z;
		if(adj > 180){
		adj -= 360;
		}
		
		if(adj < -180){
		adj += 360;
		}
		

		if (Mathf.Abs(adj) > 2 && Mathf.Abs(rigidbody2D.angularVelocity) < maxTurnVelocity){
		//Debug.Log("adjustment: " + adj + " current velocity" + rigidbody2D.angularVelocity);
		var addAmount = adj * rigidbody2D.mass;
		addAmount = Mathf.Clamp(addAmount, -100 * rigidbody2D.mass, 100 * rigidbody2D.mass);
		//Debug.Log("twerking: " + addAmount);
		rigidbody2D.AddTorque(addAmount);
		
		}
		
		if(rigidbody2D.velocity.magnitude < 50) {
		
		if(Vector3.Distance(transform.position, target_go.transform.position) < 3){
				target_go.transform.position = transform.position + transform.right * Random.Range(10 * size, 100 * size) * size;
			}
		
		
		if(Mathf.Abs(adj) < 15){
		
		rigidbody2D.AddForce(transform.right * rigidbody2D.mass * 1.2);
		}
		
		if(Mathf.Abs(adj) > 75){
		//SHIT REVERSE
			rigidbody2D.AddForce(transform.right * rigidbody2D.mass * -2);			
		
			}

		if(hit.collider != null){
		//we gonna hit somethin
		//Debug.Log("ran into" + hit.collider);
		Debug.DrawLine(transform.position, hit.point, Color.red);
		changeCourse();	
		}
		} 
	}
	// Keep us from spinning around crazy like
	rigidbody2D.angularVelocity = Mathf.Clamp(rigidbody2D.angularVelocity, -1 * maxTurnVelocity, maxTurnVelocity);

}

function OnCollisionEnter2D( col : Collision2D ){

       var inflicted = col.relativeVelocity.magnitude ; //line 1
       inflicted += col.collider.rigidbody2D.mass / 1000;
       
       if(!wrecked && col.collider.CompareTag("Player")){
 		sceneManager.SendMessage("playerKill");
 		}
 		if(!wrecked && inflicted > (size * size + 1) &&( col.collider.CompareTag("Player") || col.collider.CompareTag("rocks"))){
 		//play random crash
 		audioCo.PlayOneShot(crashSFX);
 		
 		var oldColor = renderer.material.GetColor("_Color");
 		
 		//kaboom! particles on bigger ships
 		if(size > 1 && particlePrefab != null){
 			var pipPos = new Vector3(transform.position.x, transform.position.y, -6);
 			var pip = Instantiate(particlePrefab, pipPos, transform.rotation);
 			var pipCo = pip.GetComponent(ParticleSystem);
 			pipCo.startColor = oldColor;
 		}
 		
 		
 		renderer.material.SetColor("_Color", oldColor * Color.gray);
 		if(prow != null){
 	 	prow.renderer.material.SetColor("_Color", oldColor * Color.gray);
 		
 		}
 		wrecked = true;
 	 	var msg = new Array();
 	 	msg.push(size);
 	 	msg.push(oldColor);
 	 	msg.push(rigidbody2D.mass);
 	 	msg.push(transform.position.x);
 	 	msg.push(transform.position.y);
 	 	
 	 	
	
		if(sceneManager != null){
	 		sceneManager.SendMessage("shipWrecked", msg);
	 		yield WaitForSeconds(size * 5);
	 		Destroy(gameObject); 
 		}
 		
 		}else{
 		var thisblip : AudioClip = blips[Random.Range(0,  blips.length)];
 		 audioCo.PlayOneShot(thisblip);
 		
 		}
 		
 
}   


function pointShip(start : Vector2, stop : Vector2) {

	var initBearing = getBearingFromVector2(stop);

	transform.rotation = Quaternion.AngleAxis(initBearing, Vector3.forward);
	gameObject.AddComponent(BoxCollider2D);
	
	rigidbody2D.AddForce(transform.up * speed * (20 * rigidbody2D.mass));
	
}


function getBearingFromVector2 ( v : Vector2 ){
	var bearingRads = Mathf.Atan2(v.y, v.x);
	var bearingDegs = bearingRads * Mathf.Rad2Deg;
	if(bearingDegs > 180){
	bearingDegs -=180;
	}

	return bearingDegs;

}


function changeCourse() {

	// makes a new target_go based on current direction + turning until nothing immediately blocks us.
	var vision_distance = 10.0f;
	GameObject.Destroy(target_go);
	target_go = new GameObject("target_go");
	target_go.transform.position = transform.position + transform.up * 20 * size;
	//target_go.transform.position.y =  transform.position.y + arg_stop.y;

}


function generateShip(){

	var start = new Vector2(transform.position.x, transform.position.y);
	var journeySize : int = Random.Range(100, 500);
	
	//most ships go up-down or left-right initially. only 20% otherwise.
	var plot = Random.Range(1, 100);
	var stop : Vector2;
	if(plot <= 40){
	
	 stop = new Vector2(Random.Range(0, journeySize) - journeySize/2, 0);
	
	}else if(plot <= 80){
	
		 stop = new Vector2(0, Random.Range(0, journeySize) - journeySize/2);

	
	}else{
		 stop = new Vector2(Random.Range(0, journeySize) - journeySize/2, Random.Range(0, journeySize) - journeySize/2);	
	
	}
	
	
	
	//
	var southness = Mathf.Clamp((transform.position.y + 50) / 15, -90, 30);
	
	if(transform.position.y < -400){
	southness = -200;
	}
	
	var midThreshold = 75 + southness/3;
	var hugeThreshold = 95 + southness/6;
	
	
	
	var preSize = Random.Range(0, 100);
	size = 0;
	if(preSize > hugeThreshold){
	size = 3;
	}else if(preSize > midThreshold){
	size = 2;
	}else{
	size = 1;
	}
	
	hull = gameObject;
	generateShip(start, stop, size);
	


}

function generateShip(arg_start : Vector2, arg_stop: Vector2, shipSize : int){

	var density = 1;
	speed = Random.Range(1.0f, 2.0f);

	var shipColor = "";

	length = 2;

	if( shipSize == 1) {
	shipColor = sColors[Random.Range(0,  sColors.Length)];
	width = 1;
	length = Random.Range(2, 5);
	}

	if( shipSize == 2){
	shipColor = mColors[Random.Range(0,  mColors.Length)];
	width = 3;
	length = Random.Range(7, 12);
	}

	if( shipSize == 3){
	shipColor = lColors[Random.Range(0,  lColors.Length)];
	width = 5;
	length = Random.Range(15, 25);
	}

	// hullType switch here
	// add shape if we don’t have it
	hull.transform.localScale.x = length;
	hull.transform.localScale.y = width;
	var newMass = width * length * density * massCO * size * size;
	hull.rigidbody2D.mass = newMass;


	//set start position
	hull.transform.position.x = arg_start.x;
	hull.transform.position.y = arg_start.y;

	//Debug.Log("color: " + shipColor + " and size: " + shipSize);
	//tint this shit
	var shipColorObj : Color;
	switch (shipColor)
	{
	case "green":
		shipColorObj = Color(0.0, 0.941, 0.162);
		break;
	case "pink":
		shipColorObj = Color(0.960, 0.141, 0.498);
		break;
	case "purple":
		shipColorObj = Color(0.474, 0.0, 0.694);
		break;
	case "yellow":
		shipColorObj = Color(0.95, 0.971, 0.05);
		break;            
	case "teal":
		shipColorObj = Color(0.690, 1.160, 0.854);
		break;            
	case "orange":
		shipColorObj = Color(1, 0.435, 0.0);
		break;                
	case "red":
		shipColorObj = Color(0.792, 0.0, 0.345);
		break;            
	case "black":
		shipColorObj = Color(0.7, 0.7, 0.7);
		break;     	       
	default:
		shipColorObj = Color.white;
		break;
	}

	renderer.material.SetColor("_Color", shipColorObj);
	if(prow != null){
	prow.transform.localScale.x = Random.Range(0.2, 0.75);
	prow.transform.localPosition.z = -5;
	prow.renderer.material.SetColor("_Color", shipColorObj);
	}

	// Now for the hull

	// Semicircle hull only first, but future
	//hullTypes = [“semicircle”, “blocky”, “diamond”];


	hullType = hullTypes[Random.Range(0,  hullTypes.length)];



	// To do: cool prows
	//prow.transform.position.y = length/2;
	
	
	// iinitial pointing: create target_go and run pointShip
	
	target_go = new GameObject("target_go");
	target_go.transform.position.x = transform.position.x + arg_stop.x;
	target_go.transform.position.y =  transform.position.y + arg_stop.y;
	
	pointShip(Vector2.zero, arg_stop);
	
	
	
	

}