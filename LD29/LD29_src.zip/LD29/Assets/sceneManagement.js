﻿#pragma strict

var scoreCo : GUIText;
var dataCo : GUIText;

var score : float;
var displayScore : float;
var killString : String;
var sizeStrings: Array; 
var smallJobs : Array;
var mediumJobs : Array;
var largeJobs : Array;

var pointsSFX : AudioClip;
var pointsSuperSFX : AudioClip;
var shrinkSFX : AudioClip;

var audioCo : AudioSource;
var nextPoints : float;
var pointsCooldown : float;

var temp : float;
var diameter : int;

var playerKills : int;
var player : GameObject;
var playerBody : GameObject;
var playerCollider : BoxCollider2D;

function Start () {
	DontDestroyOnLoad(gameObject);


	player = GameObject.FindGameObjectWithTag("Player");
	playerBody = GameObject.FindGameObjectWithTag("playerbody");
	playerCollider = player.GetComponent(BoxCollider2D);

	playerKills = 0;
	diameter = 20;
	temp = -50;	
	pointsCooldown = 0.05;
	nextPoints = 0.0;
	
	
	

	pointsSFX = Resources.Load("sounds/points", AudioClip);
	pointsSuperSFX = Resources.Load("sounds/points_super", AudioClip);
	shrinkSFX = Resources.Load("sounds/shrink", AudioClip);
	audioCo = gameObject.GetComponent("AudioSource");
	scoreCo = GameObject.FindGameObjectWithTag("gui_score").GetComponent(GUIText);
	dataCo = GameObject.FindGameObjectWithTag("gui_data").GetComponent(GUIText);
	var font : Font;
	killString = "";
	font = Resources.Load("telegrama_raw");
	scoreCo.font = font;
	scoreCo.fontSize = 16;
	score = 0;
	displayScore = 0;
	sizeStrings = ["nonexistant", "small", "big", "huge"];
	smallJobs = ["boat", "dinghy", "shrimp boat", "pontoon", "raft", "canoe", "lifeboat", "sloop", "ferry", "hovercraft", "trawler", "fishing boat", "boat", "boat", "cutter", "gondola", "tugboat", "patrol boat", "sloop", "caravel"];
	mediumJobs = ["barge", "yacht", "steamboat", "ferry", "boat", "steamship", "whaler", "boat", "houseboat", "scow", "windjammer", "man-o-war", "cable layer", "barge", "battlecruiser"];
	largeJobs = ["tanker", "supertanker", "oil tanker", "cruise ship", "cargo ship", "warship", "dreadnought", "galleon", "cruise ship", "oil tanker", "cruise ship", "oil tanker", "cruise ship", "oil tanker"];

	updateBody();

}




function shrinkIceberg (){

	if( diameter < 8){
	diameter--;
	
	}else if(diameter < 15){
	diameter -= 2;
	}else{
	diameter -= 5;
	}
	
	if(diameter < 2){
	Destroy(player);
	WaitForSeconds(1);
	Application.LoadLevel("gameover");
	PlayerPrefs.SetFloat("lastScore", score);
	
	Destroy(gameObject);

	}else{
	
		audioCo.PlayOneShot(shrinkSFX);

	}
	
	temp = Mathf.Clamp(-5 * diameter, -100, 0);
	updateBody();
	

}

function updateBody() {

	playerBody.transform.localScale.x = diameter;
	playerBody.transform.localScale.y = diameter;
	var newMass = diameter * diameter * 50;
	player.rigidbody2D.mass = newMass;
	playerCollider.size.x = diameter;
	playerCollider.size.y = diameter;
//	Debug.Log("new mass" + newMass);
	

}

function playerKill() {

	playerKills++;
	player.SendMessage("playerKill");
}



function playerRock(inflicted : float) {

	temp += inflicted;
}




function Update () {


	//player melting
	
	var southness = -1 * Mathf.Clamp( Mathf.Round(player.transform.position.y / 100) , -15, 0);
	
//	Debug.Log("player degrees south: " + southness);
	
	if( temp > 0){
	shrinkIceberg();
	}else{
	temp += Time.deltaTime * (2 + southness);
	}

	if(score > displayScore && Time.time > nextPoints){
	var diff = score - displayScore;
	nextPoints = Time.time + pointsCooldown;
	
	if(diff < 1000){
	displayScore += 50;
	audioCo.PlayOneShot(pointsSFX);
	}else if( diff < 10000){
	displayScore += 500;
	audioCo.PlayOneShot(pointsSFX);
	}else{
	displayScore += 5000;
	audioCo.PlayOneShot(pointsSuperSFX);
	nextPoints += pointsCooldown * 2;
	}
	
	}
	scoreCo.text = "Score: " + displayScore + killString + "\n" + "hits: " + playerKills;
	
	dataCo.text = "Speed: " + player.rigidbody2D.velocity.magnitude.ToString("F1") + " knots \n" + "\n Latitude: " + (75-(southness*5))+  " \n" + "Temp: " + temp.ToString("F1") + "\n" + "Area: " + (diameter -1) + " km^2";

}


function checkDistanceFromPlayer( v : Vector2 ){

	var pv = new Vector2(player.transform.position.x, player.transform.position.y);
	
	return (Vector2.Distance(v, pv) < 50);

}

function shipWrecked ( ship : Array ) {

	if(checkDistanceFromPlayer( new Vector2(ship[3], ship[4]) )){
	//Debug.Log("SHIP DOWNED. SIZE: " + ship[0] + " color: " + ship[1] + " tons: " + ship[2] );
	var size = ship[0];
	var addl : float = ship[2];
	score += addl;
	scoreCo.color = ship[1];
	var boatname = "";
	if( size == 1){
		boatname = mediumJobs[Random.Range(0, mediumJobs.length)];
		temp -= 2;
	}
	if( size == 2){
		boatname = mediumJobs[Random.Range(0, mediumJobs.length)];
		temp -=5;
	}
	if( size == 3){
		boatname = largeJobs[Random.Range(0, largeJobs.length)];
		temp -= 20;
	}
	
	boatname = boatname.ToUpper();
	killString = " WRECKED A " + sizeStrings[ship[0]] + " " + boatname + " of " + addl + " tons!" ;
	}

}