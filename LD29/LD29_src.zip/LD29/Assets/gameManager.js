﻿#pragma strict

var started : boolean;

var music1 : AudioClip;
var music2 : AudioClip;
var audioCo : AudioSource;

var finalScore : GUIText;
var scoreText : GUIText;
var RoyalThreshold : float;
var musicVol : float = 0.35;



function Start () {

RoyalThreshold = 1000000;

DontDestroyOnLoad(gameObject);
started = false;


// load SFX
music1 = Resources.Load("sounds/music1", AudioClip);
music2 = Resources.Load("sounds/music2", AudioClip);


audioCo = gameObject.GetComponent("AudioSource");
audioCo.loop = true;
showTitleScore();
startMusic();

}


function showTitleScore(){


		if(PlayerPrefs.HasKey("hiscore")){
			 scoreText = GameObject.FindGameObjectWithTag("gui_score").GetComponent(GUIText);
			var title_score = PlayerPrefs.GetFloat("hiScore");
			scoreText.text = "High score: " + title_score; 
 	}
	

}

function startMusic(){

audioCo.volume = musicVol;

if(PlayerPrefs.HasKey("hiScore") && PlayerPrefs.GetFloat("hiScore") >= RoyalThreshold){

audioCo.clip = music2;


}else{

audioCo.clip = music1;

}

audioCo.Play();

}



function resetGame(){

	Application.LoadLevel("startMenu");
	Destroy(gameObject);

}


function Update () {

	if(Input.GetButtonDown("Fire1") && !started){
		started = true;
		var pick = Random.Range(1, 3);
		
	
		Application.LoadLevel("level" + pick);
		
		
	}
	var DEV = false;
	if(DEV && Input.GetKeyDown("z") && !started){
		PlayerPrefs.SetFloat("hiScore", 1000000.0);
		Debug.Log("Set MEELION");
	}
	
	if(DEV && Input.GetKeyDown("y") && !started){
		PlayerPrefs.SetFloat("hiScore", 00.0);
		Debug.Log("Set ZERO");
	}
	
	}
	
	
	function gameOver() {
	
	       StartCoroutine(FadeMusic(4));
	       

	}
	
	
	function OnLevelWasLoaded( level : int ){
	//		Debug.Log("LVL " + level);

	if(audioCo.volume < musicVol){
	
	startMusic();
	}
	
	
	
	
	
	if( level == 2){
		gameOver();
		
		scoreText = GameObject.FindGameObjectWithTag("gui_score").GetComponent(GUIText);
		
		yield WaitForSeconds(2);
		started = false;
		var ls = PlayerPrefs.GetFloat("lastScore");
		var hs = PlayerPrefs.GetFloat("hiScore");
		
		scoreText.text = "your score: " + ls;
		
		if(ls > hs){
		
		//new high score!
		PlayerPrefs.SetFloat("hiScore", ls);
		scoreText.text += "\n" + "NEW high score: " + ls;

		
		if( ls >= RoyalThreshold ){
		// New unlock!
		scoreText.text += "\n" + "UNLOCKED ROYAL SOUNDTRACK";
		startMusic();

		
		
		}
		
		}else{
		
		scoreText.text += "\n" + "high score: " + hs;
		
		}
	}
	
	}

 
  function FadeMusic(seconds : float)
  {
  	var volume;
      var initialVolume = audioCo.volume;
      var t = 1.0;
      while(t > 0)
      {
          t -= Time.deltaTime/seconds;
          volume = Mathf.Lerp(0.0, musicVol, t);
          audioCo.volume = volume;
         // Debug.Log("VOLUME: " + audioCo.volume);

          yield null;
      }
      
  }
	
	

