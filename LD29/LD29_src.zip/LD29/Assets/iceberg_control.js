﻿#pragma strict


var speedCO = 10.0;
var boostCooldown = 2.0;
var nextBoost = 0.0;
var massCO = 1000.0;
var boostCO = 300.0;
var moveCO = 40.0;
var boostIncr = 100.0;

var boostSFX : AudioClip;
var rocksmashSFX : AudioClip;

var audioCo : AudioSource;
var sceneManager : GameObject;
function Start () {

// initial size and mass
	//rigidbody2D.mass = massCO;

// load SFX
boostSFX = Resources.Load("sounds/boost1", AudioClip);
rocksmashSFX = Resources.Load("sounds/rocksmash", AudioClip);

audioCo = gameObject.GetComponent("AudioSource");
sceneManager = GameObject.FindGameObjectWithTag("GameController");

}


function playerKill () {

	boostCO += boostIncr;
	boostCooldown = Mathf.Clamp(boostCooldown - 0.1, 1.0, 2.0);


}


function OnCollisionEnter2D( col : Collision2D ){

       var inflicted = col.relativeVelocity.magnitude ; //line 1
       inflicted += col.collider.rigidbody2D.mass / 1000;
       
       if(col.collider.CompareTag("rocks")){
       
 		sceneManager.SendMessage("playerRock", inflicted);
 		 	audioCo.PlayOneShot(rocksmashSFX);
	
 		}
 		
 		}

function Update () {
	
	var heading = Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
//	Debug.Log(heading);
	 rigidbody2D.AddForce(heading * speedCO * moveCO);
	 
	 
	 if(Input.GetButtonDown('Fire1') && Time.time > nextBoost){
	 	audioCo.PlayOneShot(boostSFX);
	 	nextBoost = Time.time + boostCooldown;
	 	var sizeEasing = Mathf.Clamp(rigidbody2D.mass / 10000, 1, 10);
	 	var fb = massCO * boostCO * sizeEasing ;
	 	
	 	
//	 	Debug.Log("raw fb" + fb + " vs " + rigidbody2D.mass * 10000);
	 	fb = Mathf.Clamp(fb, 100.0, rigidbody2D.mass * 10000);
	 	
	 	rigidbody2D.AddForce( heading * fb);
	 //	Debug.Log("BOOST");
	 
	 }
	 
	 if(Input.GetKeyDown('p')){
	 	sceneManager.SendMessage("shrinkIceberg");
	 
	 }
	 
	 
	 
	 
}