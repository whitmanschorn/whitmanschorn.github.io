﻿#pragma strict


var gt : GUIText;
var title_go : GameObject;

function Start () {
	transform.position = Vector3.zero;
	gt = GetComponentInChildren(GUIText);
	var font = Resources.Load("telegrama_raw");
	gt.font = font;
	gt.fontSize = 24;
	gt.text = "";
	gt.color = Color.white;
	title_go = GameObject.FindGameObjectWithTag("title");
}

function Update () {



	if(Input.GetButtonDown('controls')){
	
	Time.timeScale = 0;
	gt.text = "Controls \n \n" + "Arrow keys: Move \n" + "A: Boost! \n" + "I/O: Zoom [i]n or [o]ut \n \n" + "Instructions: Ships will avoid your snow-capped peak,\n" + "but can't see what's " + "UNDER THE SURFACE.\n\n" + "Destroy ships, avoid rocks," + "and take back the ocean!!!\n\n" + "Created in 48 hours by @what_whit for Ludum Dare 29";
	
	if(title_go != null){
		title_go.active = false;
	}
	
	}
	
	if(Input.GetButtonUp('controls')){
	
	Time.timeScale = 1.0;
	gt.text = "";
	
	
		if(title_go != null){
		title_go.active = true;
	}
	
	}

}