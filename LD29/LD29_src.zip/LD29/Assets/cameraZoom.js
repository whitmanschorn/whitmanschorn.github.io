﻿#pragma strict

var zoom : float;
var desiredZoom : float;
var zoomCo : float;

function Start () {

desiredZoom = 40.0;
zoom = 20.0;
zoomCo = 25.0f;


}

function Update () {

	if(zoom < desiredZoom){
		zoom = Mathf.Clamp(Time.deltaTime * (zoomCo) + zoom, 10, 160);
		Camera.main.orthographicSize = zoom;
	}

	if(zoom > desiredZoom){
		zoom = Mathf.Clamp(zoom - Time.deltaTime * zoomCo, 10, 160);
		Camera.main.orthographicSize = zoom;
	}

	 
	 if(Input.GetButtonDown('zoom_in')){
	 
	 	desiredZoom *= 0.5;
	 
	 }
	 	 
	 if(Input.GetButtonDown('zoom_out')){
	 
	 	desiredZoom *= 2;
	 
	 }
	 

}